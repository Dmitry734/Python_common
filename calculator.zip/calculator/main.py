import controller

controller.button_click(0)
